<?php 
$config['email_config'] = array(
                'mailtype' => 'HTML',
                'protocol' => 'SMTP',
                'smtp_host' => 'ssl://smtp.hostinger.in',
                'smtp_port' => '587',
                'smtp_user' => 'support@waptechy.com',
                'smtp_pass' => 'Parmar@1432',
                'charset' => 'utf-8',
                'newline' => '\r\n',
            ); 

?>